[IN DEVELOPMENT]  
  
A chess game created using QtCreator written in C++, with a machine learning (neural networks) engine written in Python using PyTorch. 

See README.txt for details about project organization.
