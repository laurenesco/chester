#include "evaluationbar.h"

EvaluationBar::EvaluationBar(QWidget *parent)
    : QWidget{parent}
{

}
