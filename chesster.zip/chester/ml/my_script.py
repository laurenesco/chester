def add_numbers(a, b):
    result = a + b
    print(f"The sum of {a} and {b} is: {result}")
    return("Hi from inside python!!!")
